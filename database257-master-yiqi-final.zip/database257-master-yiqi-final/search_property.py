from flask import Flask, render_template, request, redirect
import sqlite3
from dotmap import DotMap
from bs4 import BeautifulSoup

app = Flask(__name__)


# connection = pymysql.connect(host='localhost',
#                              user='root',
#                              password='001745aA',
#                              db='airbnb',
#                              charset='utf8mb4',
#                              cursorclass=pymysql.cursors.DictCursor)


@app.route("/search_property", methods=["GET"])
def search_property():
    html_soup = BeautifulSoup(open("templates/search_property.html"), 'html.parser')
    body = html_soup.find('body')
    formsoup = body.find('form')
    form_group = formsoup.find('div', class_='form-group')
    d = {}
    for input_entry in form_group.find_all('input', class_='form-control'):
        name = input_entry.get('id')
        d[name] = request.form[name]
    for select_entry in form_group.find_all('select', class_='form-control'):
        name = select_entry.get('id')
        d[name] = request.form[name]
    d = DotMap(d)
    state = d['state']
    city = d['city']
    street = d['street']
    property_type = d['property_type']
    room_type = d['room_type']
    bed_type = d['bed_type']
    no_bathrooms = d['no_bathrooms']
    no_bedrooms = d['no_bedrooms']
    minimum_stay = d['minimum_stay']
    capacity = d['capacity']
    rate = d['rate']
    connection = sqlite3.connect('user_6table.db')
    c = connection.cursor()
    if street=='':
        # select_stmt = "SELECT * FROM employees WHERE emp_no = %(emp_no)s"
        # c.execute(select_stmt, {'emp_no': 2})
        select_stmt = """ select * from property where property_id in 
        (select property_id from location where state=%(state)s and city=%(city)s and street=%(street)s) """
        c.execute(select_stmt, {'state':state, 'city':city})
        c.commit()
    else:
        select_stmt = """ select * from property where property_id in 
               (select property_id from location where state=%(state)s and city=%(city)s) """
        c.execute(select_stmt, {'state': state, 'city': city, 'street': street})
        c.commit()
    rows = c.fetchall()
    return render_template("search_property.html", **locals())


#     cursor = connection.cursor()
#     sql = "select * from property limit 5"
#     cursor.execute(sql)
#     rows = cursor.fetchall()
#     return render_template("index.html", **locals())
#
#
if __name__ == "__main__":
    app.run()
