import sqlite3
from flask import Flask, render_template, request, redirect, flash, url_for

app = Flask(__name__)
app.secret_key = 'this_is_secret'
from dotmap import DotMap
from bs4 import BeautifulSoup


# import pdb; pdb.set_trace()


@app.route("/", methods=["GET"])
def create_tables():
    '''this funtion creates tables in our database if they do not exist'''

    connection = sqlite3.connect('user_new.db')
    c = connection.cursor()

    # Create table
    c.execute("""
            CREATE TABLE IF NOT EXISTS location
            (	property_id integer PRIMARY KEY AUTOINCREMENT, 
                country text NOT NULL,
                state text NOT NULL,
                city text NOT NULL,
                street text ,
                zip_code text
            );""")

    c.execute("""
            CREATE TABLE IF NOT EXISTS owner
            (	host_id integer PRIMARY KEY AUTOINCREMENT,
                firstname text NOT NULL, 
                lastname text NOT NULL,
                phone varchar(10) NOT NULL,
                email text NOT NULL,
                password text NOT NULL
            );""")

    c.execute("""
        CREATE TABLE IF NOT EXISTS property
        (	property_id integer PRIMARY KEY AUTOINCREMENT,
            property_type text NOT NULL, 
            capacity  integer NOT NULL, 
            minimum_stay integer NOT NULL,
            no_bathrooms float NOT NULL,
            no_bedrooms integer NOT NULL,
            bed_type text NOT NULL,
            room_type text NOT NULL,
            rate float NOT NULL,
            host_id integer NOT NULL
        );""")

    c.execute("""
        CREATE TABLE IF NOT EXISTS guest
        (   guest_id integer PRIMARY KEY AUTOINCREMENT,
            firstname text NOT NULL, 
            lastname text NOT NULL,
            phone varchar(10) NOT NULL,
            email text NOT NULL,
            password text NOT NULL
        );""")

    c.execute("""
    CREATE TABLE IF NOT EXISTS reservation
    (   property_id integer,
        guest_id integer,
        booked integer NOT NULL 
    );""")

    connection.commit()
    connection.close()

    return render_template("home.html")

    # return "OK"


@app.route("/home", methods=["GET"])
def render_home():
    return render_template("home.html")


@app.route("/sign_up", methods=["GET"])
def sign_up_render():
    return render_template("sign_up.html")


@app.route("/sign_up", methods=["GET", "POST"])
def sign_up():
    email = request.form.get("email")
    password = request.form.get("password")
    firstname = request.form.get("firstname")
    lastname = request.form.get("lastname")
    user_type = request.form.get("user_type")
    phone = request.form.get("phone")

    connection = sqlite3.connect('user_new.db')
    c1 = connection.cursor()
    c1.execute(""" SELECT * FROM {} WHERE email=? """.format(user_type), (email,))
    user = c1.fetchall()
    connection.commit()
    print(user)
    if len(user) != 0:
        return render_template("sign_up.html", message="this email id has already  signed up!")  # **d)

    # pdb.set_trace()
    print(firstname, lastname, phone, email)
    # 3. Populate tables
    connection = sqlite3.connect('user_new.db')
    c = connection.cursor()
    if user_type == 'owner':
        c.execute(""" INSERT INTO owner (firstname,lastname, phone,email,password)
        VALUES (?, ?,? ,?,?)""", [firstname, lastname, phone, email, password])
        # GET host_id based on hostname from owner table
    elif user_type == "guest":
        c.execute(""" INSERT INTO guest (firstname,lastname, phone,email,password)
        VALUES (?, ?,? ,?,?)""", [firstname, lastname, phone, email, password])

    connection.commit()
    # G

    message = ('Welcome! You have successfully created your ' + user_type.upper() + ' account! ')
    # return redirect(url_for('login_form'),message=message)
    return render_template("sign_up.html", message=message)  # **d)


@app.route("/list_property", methods=["GET"])
def list_property_render():
    return render_template("list_property.html")


@app.route("/list_property", methods=["POST"])
def list_property():
    # 1. get all id in class form-group from the html instead of writing all of them
    # 2. get values of fields from form
    user_type = request.form["user_type"]
    if user_type == "guest":
        return render_template("list_property.html", message="You should signup as an OWNER")  # **d)
    # check login
    email = request.form["email"]
    password = request.form["password"]
    connection = sqlite3.connect('user_new.db')
    c1 = connection.cursor()
    c1.execute(""" SELECT * FROM owner WHERE email=? and password=? """, (email, password,))
    user = c1.fetchall()
    connection.commit()
    print('11')
    if len(user) == 0:
        return render_template("list_property.html", message="You email/password is wrong or do not exist.")  # **d)
    host_id = user[0][0]
    print('22')
    print(host_id)
    d = {}
    # had issues reading select class so read them in hard code
    d["street"] = request.form["street"]
    d["zip_code"] = request.form["zip_code"]
    d["rate"] = request.form["rate"]
    d["no_bathrooms"] = request.form["no_bathrooms"]
    d["no_bedrooms"] = request.form["no_bedrooms"]
    d["minimum_stay"] = request.form["minimum_stay"]
    d["capacity"] = request.form["capacity"]
    # d["rate"]=float(d["rate"])
    d["property_type"] = request.form["property_type"]
    d["bed_type"] = request.form["bed_type"]
    d["room_type"] = request.form["room_type"]
    d["country"] = request.form["country"]
    d["state"] = request.form["state"]
    d["city"] = request.form["city"]
    # allow dot notation in dict above
    d = DotMap(d)
    print(d)
    print('33')
    print(user[0])
    print('44')
    # 3. Populate tables
    connection = sqlite3.connect('user_new.db')
    c = connection.cursor()
    # GET host_id based on hostname from owner table
    # host_id=int(1111111) #filler
    # host_id=c.execute("""SELECT host_id FROM owner WHERE firstname=? AND lastname=?""",(d.firstname,d.lastname))
    # host_id=host_id.fetchone()[0]
    c.execute(""" INSERT INTO location (country,state,city,street,zipcode)
        VALUES (?, ?, ?, ?,?)""", [d.country, d.state, d.city, d.street, d.zip_code])
    # c.execute("""SET @last_id = LAST_INSERT_ID()""")
    property_id = c.lastrowid
    # print(type(property_id))
    c.execute(""" INSERT INTO property (property_id,property_type,rate,room_type,bed_type,no_bathrooms,no_bedrooms,minimum_stay,capacity, host_id)
    VALUES (?, ?, ?, ?,?,?,?,?,?,?)""",
              [property_id, d.property_type, d.rate, d.room_type, d.bed_type, d.no_bathrooms, d.no_bedrooms,
               d.minimum_stay, d.capacity, int(host_id)])

    connection.commit()
    # user[1].upper(),

    message = (user[0][
                   1].upper() + ' you have successfully listed a property!' + '\n' + 'Get ready to handle money and guests :) ')
    # return redirect(url_for('login_form'),message=message)
    return render_template("list_property.html", message=message)  # **d)


@app.route("/search_property", methods=["GET"])
def search_property_render():
    return render_template("search_property.html")


@app.route("/search_property", methods=["GET", "POST"])
def search_property():
    state = request.form['state']
    city = request.form['city']
    street = request.form['street']
    property_type = request.form['property_type']
    room_type = request.form['room_type']
    bed_type = request.form['bed_type']
    no_bathrooms = request.form['no_bathrooms']
    no_bedrooms = request.form['no_bedrooms']
    minimum_stay = request.form['minimum_stay']
    capacity = request.form['capacity']
    rate = request.form['rate']
    print(state, city, street, property_type, room_type, bed_type, no_bedrooms, no_bathrooms, minimum_stay, capacity,
          rate)
    connection = sqlite3.connect('user_new.db')
    c = connection.cursor()
    if street == '':
        c.execute(""" SELECT property.property_id, property_type, room_type, bed_type, no_bathrooms,no_bedrooms, capacity, minimum_stay, rate, state, city, street, zipcode
             FROM property join location 
              on property.property_id = location.property_id 
              WHERE property.property_id IN
              (SELECT property_id FROM location WHERE state= ? and city= ?)
              and  property_type=? and room_type=? and bed_type=?
              and no_bathrooms>=? and no_bedrooms>=? and capacity>=?
              and minimum_stay<=? and cast(substr(rate,2) as FLOAT)<= ?
             """, (state, city, property_type, room_type, bed_type, no_bathrooms, no_bedrooms, capacity, minimum_stay,
                   float(rate)))
        rows = c.fetchall()
        connection.commit()
    c.execute(""" SELECT property.property_id, property_type, room_type, bed_type, no_bathrooms,no_bedrooms, capacity, minimum_stay, rate, state, city, street, zipcode
                FROM property join location 
                 on property.property_id = location.property_id 
                 WHERE property.property_id IN
                 (SELECT property_id FROM location WHERE state= ? and city= ? and street LIKE ?)
                 and  property_type=? and room_type=? and bed_type=?
                 and no_bathrooms>=? and no_bedrooms>=? and capacity>=?
                 and minimum_stay<=? and cast(substr(rate,2) as FLOAT)<= ?
                """,
              (state, city, '%' + street + '%', property_type, room_type, bed_type, no_bathrooms, no_bedrooms, capacity,
               minimum_stay,
               float(rate)))
    rows = c.fetchall()
    connection.commit()
    print(rows)
    print(type(rows))
    if request.form['submit'] == 'search':
        return render_template("search_property.html", columns=rows)
    elif request.form['submit'] == 'book':
        property_id = request.form.get('select')
        print(property_id)
        print(type(property_id))
        user_type = request.form["user_type"]
        email = request.form["email"]
        password = request.form["password"]
        if user_type == "owner":
           return render_template("search_property.html", message="You should signup as an guest")
        connection = sqlite3.connect('user_new.db')
        c1 = connection.cursor()
        c1.execute(""" SELECT * FROM guest WHERE email=? and password=? """, (email, password,))
        user = c1.fetchall()
        print(user)
        connection.commit()
        print('22')
        if len(user) == 0:
            return render_template("search_property.html", message="You email/password is wrong or do not exist.")  # **d)
        guest_id = user[0][0]
        print(guest_id)
        print(type(guest_id))
        booked = int(1)
        connection = sqlite3.connect('user_new.db')
        c2 = connection.cursor()
        c2.execute(""" INSERT INTO reservation (guest_id,property_id, booked)
            VALUES (?, ?,? )""", [int(guest_id), int(property_id),booked])
        connection.commit()
        return render_template("search_property.html", message='You have booked successfully!')
        #return redirect(url_for("search_result",property=property_id))
    # booked = int(1)
    # connection = sqlite3.connect('user_new.db')
    # c2 = connection.cursor()
    # c2.execute(""" INSERT INTO reservation (guest_id,property_id, booked)
    #     VALUES (?, ?,? )""", [guest_id, int(property_id),booked])
    #connection.commit()
    #return redirect(url_for("/search_result", columns=rows))  # **locals())


# @app.route("/search_result<property>", methods=["GET","POST"])
# def search_result(property):
#     property_id = property
#     print(property_id)
#     return render_template("search_result.html")
# @app.route("/search_result/<columns>", methods=["GET","POST"])
# def search_result(columns):
#     r = columns
#     r = r.strip('[(')
#     r = r.strip(')]')
#     r_split = r.split('), (')
#     r_tuple = [tuple(x.split(', ')) for x in r_split]
#     rows = []
#     for i in range(len(r_tuple)):
#         s = [x.strip("'") for x in r_tuple[i]]
#         rows.append(s)
#     print('11')
#     print(rows)
#
#     return render_template("search_result.html", columns=rows)

#
# @app.route("/search_property", methods=["GET", "POST"])
# def search_result():
#     user_type = request.form["user_type"]
#     if user_type == "owner":
#         return render_template("search_result.html", message="You should signup as an guest")  # **d)
#     # check login
#     print('11')
#     email = request.form["email"]
#     password = request.form["password"]
#     connection = sqlite3.connect('user_new.db')
#     c1 = connection.cursor()
#     c1.execute(""" SELECT * FROM guest WHERE email=? and password=? """, (email, password,))
#     user = c1.fetchall()
#     print(user)
#     connection.commit()
#     print('22')
#     if len(user) == 0:
#         return render_template("search_result.html", message="You email/password is wrong or do not exist.")  # **d)
#     host_id = user[0][0]
#     property_id = request.form.get('select')
#     print(property_id)
#     print(host_id)
#     return render_template("search_result.html")


if __name__ == "__main__":
    app.run()


    # WHERE (property_id IN
    #      (SELECT property_id FROM location WHERE state= ? and city= ?)
    # SELECT property_type, room_type, bed_type, no_bathrooms,no_bedrooms, capacity, minimum_stay, rate, state, city, street, zipcode
    #      FROM property join location
    #       on property.property_id = location.property_id
    #       WHERE property.property_id IN
    #       (SELECT property_id FROM location WHERE state= ? and city= ?)
    #       and  property_type=? and room_type=? and bed_type=?
