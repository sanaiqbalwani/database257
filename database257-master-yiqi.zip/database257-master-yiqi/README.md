# database257
Property Renting Database


download the folder  

Go to the directory from your terminal  

run python webserver.py  

open http://localhost:5000  


