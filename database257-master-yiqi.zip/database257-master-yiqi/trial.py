
d={'state':1, 'country':6}
print(d['state'])